# -*- coding: utf-8 -*-
"""
Created on Tue Jun  2 10:39:21 2020

@author: Leena Stenberg
"""

import math
import pandas as pd
import numpy as np
from scipy.interpolate import interp1d
from scipy import optimize

"""
Example inputs for calculating the financial stuff

nScen = 5 # Number of scenarios, including control scenario
simYears = 20. # Number of simulation years
interest = 3. # Interest rate, in percentage, e.g. 3
logPrice = 57.93 # Price of logs, eur/m3
pulpPrice = 20.07 # Price of pulp wood, eur/m3
DNMcost = 200. # Cost of DNM, eur/ha
susiPath = r'C:/Python-LS/susi51' # Example of Susi path
mottifile='motti_file_name.xls' # Example of Motti file name

"""

def get_logs_pulp(ifile):

    """    
    Inputs:
        ifile = Motti-file with path

    Outputs:
        volToLogs = function for volume vs. logs
        volToPulp = function for volume vs. pulp
        
    """
    
    cnames=['yr', 'age', 'N', 'BA', 'Hg', 'Dg', 'hdom', 'vol', 'logs', 'pulp', 'loss', 'yield','mortality', 
            'stempulp', 'stemloss', 'branch_living', 'branch_dead', 'leaves', 'stump', 'roots_coarse', 'roots_fine']

    df = pd.read_excel(ifile, sheetname=0, parse_cols=range(22), skiprows=1, header=None )
    df = df.drop([0], axis=1)
    df.columns=cnames
    
    #--- find thinnings and add a small time to lines with the age to enable interpolation
    df = df[df['vol']!=0]    
    steps = np.array(np.diff(df['vol']), dtype=float)
    idx = np.ravel(np.argwhere(steps<1.))+1
    df['age'][idx]=df['age'][idx]+5./365.
    
    #--- create interpolation functions to follow the Motti-defined framework of forest development
    x = np.insert(df['logs'].values, 0, 0.)   
    v = np.insert(df['vol'].values, 0, 0.)
    volToLogs = interp1d(v,x,fill_value='extrapolate')

    p = np.insert(df['pulp'].values, 0, 0.)   
    v = np.insert(df['vol'].values, 0, 0.)
    volToPulp = interp1d(v,p,fill_value='extrapolate')
    
    return volToLogs, volToPulp


def get_profit(susiPath, mottifile, simYears, interest, nScen, grData, logPrice, pulpPrice, DNMcost): 

    """
    Calculates the profits (eur/ha) and internal interest rate (%) assuming 
    the first scenario is the control scenario.
    
    Inputs:
        susiPath = file path for Susi files
        mottifile = name of the Motti file
        simYears = number of simulation years
        interest = interest rate (%)
        nScen = number of scenarios, assuming the first one is control scenario
        grData = gr_output.csv or similar dataframe including the stand volumes (m3/ha) at the end of the simulation for each scenario
        
            Example:
                
            grData = pd.DataFrame([[147., 155., 158., 160., 161.]]) # first number represents the end-of-simulation volume (m3/ha) in control scenario

        logPrice = current price of logs (eur/m3)
        pulpPrice = current price of pulp (eur/m3)
        DNMcost = current cost of DNM (eur/ha)
      
        
    Outputs:
        profitResp = profit response (eur/ha) to DNM for each scenario; profit/loss caused by deepening ditch from the control scenario to other scenarios
        internalRate = internal rate of interest (%) for each scenario in cases when ditches are deepened from the control scenario to other scenarios
    
    """
    
    internalRate = pd.Series([])
    profitResp = pd.Series([])

    ifile = susiPath + '/motti2/' + mottifile    
    volToLogs, volToPulp = get_logs_pulp(ifile) # volToLogs and volToPulp functions
	
    volEndControl = grData[0][0] # Volume (m3/ha) at end of simulation in control scenario
    
    logsEndControl = volToLogs(volEndControl) # Logs (m3/ha) at the end of simulation in control scenario
    pulpEndControl = volToPulp(volEndControl) # Pulp (m3/ha) at the end of simulation in control scenario
    
    eurControl = logsEndControl * logPrice + pulpEndControl * pulpPrice # Stand price in eur/ha at the end of simulation in control scenario
	
    for i in range(1,nScen):

        volEndDNM = grData[i][0]
        
        logsEndDNM = volToLogs(volEndDNM) # Logs (m3/ha) at the end of simulation in DNM scenario
        pulpEndDNM = volToPulp(volEndDNM) # Pulp (m3/ha) at the end of simulation in DNM scenario

        eurDNM = logsEndDNM * logPrice + pulpEndDNM * pulpPrice # Stand price in eur/ha at the end of simulation in DNM scenario
        
        # profitResponse-function: 
        # Function to calculate profit response to DNM (eur/ha) with interest rate x
        # Logs and pulp values are discounted.
        
        # Continuous discount: Pc = Pf / e^(rt)
        # Pc = current value
        # Pf = future value
        # e = 2.71828... Euler's number / Neperin luku
        # r = annual interest rate
        # t = time in years
        
        def profitResponse(x):
            return (eurDNM /  math.exp(x/100. * simYears) - DNMcost) - \
                (eurControl / math.exp(x/100. * simYears))
        
        # Solve the internal rate of interest i.e. the interest rate x that results in profitResponse(x)=0
        try:
            sol = optimize.root(profitResponse, [0]) # 0 is the starting point for optimization
            internalRate[i] = sol.x[0]
        
        except OverflowError: # In case where roots (of the optimized function) cannot be found, e.g. if tree growth is 'negative'
            internalRate[i] = float('inf')
            
        profitResp[i] = profitResponse(interest) # profit response (eur/ha) with the given interest rate

    return profitResp, internalRate
